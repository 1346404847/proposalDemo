<?php

namespace JsonRpc2\Dto;

use JsonRpc2\Dto;

class Test extends Dto {
    /** @var string */
    public $message;
} 